import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { 
  Menu, 
  Settings, 
  MessageSquare, 
  Send,
  Plus,
  User,
  Bot
} from 'lucide-react';

interface Message {
  id: string;
  content: string;
  sender: 'user' | 'assistant';
  timestamp: Date;
}

interface Conversation {
  id: string;
  title: string;
  lastMessage: string;
  timestamp: Date;
  messages: Message[];
}

export default function Gemini() {
  const { user, logout } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [activeConversation, setActiveConversation] = useState<string>('1');

  // Enhanced mock conversations data with full chat histories
  const [conversations] = useState<Conversation[]>([
    {
      id: '1',
      title: 'React best practices',
      lastMessage: 'What are the latest React best practices for 2024?',
      timestamp: new Date(Date.now() - 1000 * 60 * 30),
      messages: [
        {
          id: '1-1',
          content: 'What are the latest React best practices for 2024?',
          sender: 'user',
          timestamp: new Date(Date.now() - 1000 * 60 * 30)
        },
        {
          id: '1-2',
          content: 'Here are the key React best practices for 2024:\n\n**1. Use React 18 Features**\nLeverage concurrent features like Suspense, useTransition, and useDeferredValue for better performance and user experience.\n\n**2. Server Components**\nAdopt React Server Components for better SEO and initial load performance. They render on the server and reduce bundle size.\n\n**3. Custom Hooks**\nExtract reusable logic into custom hooks to keep components clean and promote code reuse.\n\n**4. TypeScript Integration**\nUse TypeScript for better type safety, improved developer experience, and fewer runtime errors.\n\n**5. State Management Strategy**\n- useState/useReducer for local component state\n- Context API for shared state across components\n- External libraries like Zustand or Redux Toolkit for complex global state\n\n**6. Performance Optimization**\n- Use React.memo for preventing unnecessary re-renders\n- Implement useMemo and useCallback judiciously\n- Code splitting with React.lazy and Suspense\n\n**7. Error Boundaries**\nImplement error boundaries to gracefully handle component errors and provide fallback UI.\n\n**8. Testing Strategy**\nWrite comprehensive tests using React Testing Library and Jest, focusing on user behavior rather than implementation details.',
          sender: 'assistant',
          timestamp: new Date(Date.now() - 1000 * 60 * 29)
        },
        {
          id: '1-3',
          content: 'Can you explain more about React Server Components and how they differ from regular components?',
          sender: 'user',
          timestamp: new Date(Date.now() - 1000 * 60 * 25)
        },
        {
          id: '1-4',
          content: 'React Server Components (RSC) represent a paradigm shift in how we think about React applications:\n\n**Key Differences:**\n\n**Server Components:**\n- Render on the server during build time or request time\n- Have zero impact on bundle size\n- Can directly access backend resources (databases, file systems)\n- Cannot use browser APIs or event handlers\n- Cannot use state or effects\n\n**Client Components:**\n- Render in the browser\n- Can use all React features (state, effects, event handlers)\n- Add to the JavaScript bundle size\n- Cannot directly access backend resources\n\n**Benefits of Server Components:**\n\n1. **Performance**: Faster initial page loads since less JavaScript is sent to the client\n2. **SEO**: Content is rendered on the server, improving search engine indexing\n3. **Security**: Sensitive operations stay on the server\n4. **Data Fetching**: Direct database access without API layers\n\n**Example Structure:**\n```jsx\n// Server Component (runs on server)\nasync function BlogPost({ id }) {\n  const post = await db.posts.findById(id); // Direct DB access\n  return (\n    <article>\n      <h1>{post.title}</h1>\n      <p>{post.content}</p>\n      <LikeButton postId={id} /> {/* Client Component */}\n    </article>\n  );\n}\n\n// Client Component (runs in browser)\n\'use client\';\nfunction LikeButton({ postId }) {\n  const [liked, setLiked] = useState(false);\n  return (\n    <button onClick={() => setLiked(!liked)}>\n      {liked ? \'❤️\' : \'🤍\'} Like\n    </button>\n  );\n}\n```\n\n**Framework Support:**\nNext.js 13+ has excellent RSC support with the App Router, making it easy to mix server and client components seamlessly.',
          sender: 'assistant',
          timestamp: new Date(Date.now() - 1000 * 60 * 24)
        }
      ]
    },
    {
      id: '2',
      title: 'JavaScript async/await',
      lastMessage: 'Explain async/await in JavaScript',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2),
      messages: [
        {
          id: '2-1',
          content: 'Explain async/await in JavaScript and how it compares to Promises',
          sender: 'user',
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2)
        },
        {
          id: '2-2',
          content: 'Async/await is syntactic sugar built on top of Promises that makes asynchronous code look and behave more like synchronous code.\n\n**Basic Syntax:**\n```javascript\nasync function fetchUserData(userId) {\n  try {\n    const response = await fetch(`/api/users/${userId}`);\n    const userData = await response.json();\n    return userData;\n  } catch (error) {\n    console.error(\'Error fetching user:\', error);\n    throw error;\n  }\n}\n```\n\n**Key Concepts:**\n\n**1. async keyword:**\n- Makes a function return a Promise\n- Allows use of await inside the function\n- Even if you return a regular value, it gets wrapped in a resolved Promise\n\n**2. await keyword:**\n- Pauses function execution until the Promise resolves\n- Returns the resolved value\n- Can only be used inside async functions\n- Throws an error if the Promise rejects\n\n**Comparison with Promises:**\n\n**Promise Chain:**\n```javascript\nfunction fetchUserData(userId) {\n  return fetch(`/api/users/${userId}`)\n    .then(response => response.json())\n    .then(userData => {\n      console.log(userData);\n      return userData;\n    })\n    .catch(error => {\n      console.error(\'Error:\', error);\n      throw error;\n    });\n}\n```\n\n**Async/Await:**\n```javascript\nasync function fetchUserData(userId) {\n  try {\n    const response = await fetch(`/api/users/${userId}`);\n    const userData = await response.json();\n    console.log(userData);\n    return userData;\n  } catch (error) {\n    console.error(\'Error:\', error);\n    throw error;\n  }\n}\n```\n\n**Advantages of Async/Await:**\n- More readable and easier to debug\n- Better error handling with try/catch\n- Easier to work with conditional logic\n- No callback hell or complex Promise chains',
          sender: 'assistant',
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2 + 1000 * 60)
        },
        {
          id: '2-3',
          content: 'How do I handle multiple async operations? Should I use Promise.all or await them separately?',
          sender: 'user',
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 1.5)
        },
        {
          id: '2-4',
          content: 'Great question! The choice depends on whether your async operations are independent or dependent on each other.\n\n**Sequential Execution (when operations depend on each other):**\n```javascript\nasync function fetchUserProfile(userId) {\n  const user = await fetchUser(userId);\n  const posts = await fetchUserPosts(user.id); // Depends on user data\n  const comments = await fetchUserComments(user.id);\n  \n  return { user, posts, comments };\n}\n```\n\n**Parallel Execution (when operations are independent):**\n```javascript\n// Using Promise.all - fails fast if any Promise rejects\nasync function fetchUserProfile(userId) {\n  try {\n    const [user, posts, comments] = await Promise.all([\n      fetchUser(userId),\n      fetchUserPosts(userId),\n      fetchUserComments(userId)\n    ]);\n    \n    return { user, posts, comments };\n  } catch (error) {\n    // If any request fails, this catch block runs\n    console.error(\'One or more requests failed:\', error);\n  }\n}\n\n// Using Promise.allSettled - waits for all, regardless of failures\nasync function fetchUserProfileSafe(userId) {\n  const results = await Promise.allSettled([\n    fetchUser(userId),\n    fetchUserPosts(userId),\n    fetchUserComments(userId)\n  ]);\n  \n  const [userResult, postsResult, commentsResult] = results;\n  \n  return {\n    user: userResult.status === \'fulfilled\' ? userResult.value : null,\n    posts: postsResult.status === \'fulfilled\' ? postsResult.value : [],\n    comments: commentsResult.status === \'fulfilled\' ? commentsResult.value : []\n  };\n}\n```\n\n**Performance Comparison:**\n- Sequential: Takes sum of all operation times\n- Parallel with Promise.all: Takes time of the slowest operation\n- Promise.allSettled: Same as Promise.all but handles failures gracefully\n\n**When to use each:**\n- **Sequential**: When later operations need data from earlier ones\n- **Promise.all**: When operations are independent and you need all to succeed\n- **Promise.allSettled**: When operations are independent but you want partial results even if some fail',
          sender: 'assistant',
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 1.4)
        }
      ]
    },
    {
      id: '3',
      title: 'CSS Grid vs Flexbox',
      lastMessage: 'When should I use CSS Grid vs Flexbox?',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24),
      messages: [
        {
          id: '3-1',
          content: 'When should I use CSS Grid vs Flexbox? I\'m always confused about which one to choose.',
          sender: 'user',
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24)
        },
        {
          id: '3-2',
          content: 'This is a common question! Both are powerful layout tools, but they excel in different scenarios:\n\n**CSS Grid - Best for 2D Layouts:**\n- Complex layouts with rows AND columns\n- When you need precise control over both dimensions\n- Card layouts, dashboards, magazine-style layouts\n- When you know the overall structure beforehand\n\n**Flexbox - Best for 1D Layouts:**\n- Single direction layouts (row OR column)\n- Component-level layouts\n- Centering items\n- Distributing space between items\n- When content size determines layout\n\n**Practical Examples:**\n\n**Use Grid for:**\n```css\n/* Dashboard layout */\n.dashboard {\n  display: grid;\n  grid-template-areas: \n    "header header header"\n    "sidebar main aside"\n    "footer footer footer";\n  grid-template-rows: 60px 1fr 40px;\n  grid-template-columns: 200px 1fr 150px;\n}\n\n/* Card grid */\n.card-grid {\n  display: grid;\n  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));\n  gap: 20px;\n}\n```\n\n**Use Flexbox for:**\n```css\n/* Navigation bar */\n.navbar {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\n\n/* Card content */\n.card {\n  display: flex;\n  flex-direction: column;\n  justify-content: space-between;\n}\n\n/* Centering */\n.center {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n```\n\n**Can I use both together?**\nAbsolutely! They work great together:\n```css\n.layout {\n  display: grid; /* Overall page structure */\n  grid-template-columns: 1fr 3fr;\n}\n\n.header {\n  display: flex; /* Header content alignment */\n  justify-content: space-between;\n  align-items: center;\n}\n```\n\n**Quick Decision Guide:**\n- Need to control both rows and columns? → Grid\n- Working with a single row or column? → Flexbox\n- Building overall page layout? → Grid\n- Aligning items within a component? → Flexbox',
          sender: 'assistant',
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 + 1000 * 60 * 2)
        }
      ]
    },
    {
      id: '4',
      title: 'TypeScript generics',
      lastMessage: 'How do TypeScript generics work?',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2),
      messages: [
        {
          id: '4-1',
          content: 'How do TypeScript generics work? I see them everywhere but don\'t understand the concept.',
          sender: 'user',
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2)
        },
        {
          id: '4-2',
          content: 'TypeScript generics are like "type variables" that allow you to write reusable code that works with multiple types while maintaining type safety.\n\n**Think of it like this:**\nInstead of writing separate functions for each type, generics let you write one function that works with any type you specify.\n\n**Basic Generic Function:**\n```typescript\n// Without generics - need separate functions\nfunction getFirstString(items: string[]): string {\n  return items[0];\n}\n\nfunction getFirstNumber(items: number[]): number {\n  return items[0];\n}\n\n// With generics - one function for all types\nfunction getFirst<T>(items: T[]): T {\n  return items[0];\n}\n\n// Usage\nconst firstString = getFirst<string>([\'a\', \'b\', \'c\']); // Type: string\nconst firstNumber = getFirst<number>([1, 2, 3]); // Type: number\nconst firstUser = getFirst<User>([user1, user2]); // Type: User\n```\n\n**Generic Interfaces:**\n```typescript\ninterface ApiResponse<T> {\n  data: T;\n  status: number;\n  message: string;\n}\n\n// Usage\nconst userResponse: ApiResponse<User> = {\n  data: { id: 1, name: \'John\' },\n  status: 200,\n  message: \'Success\'\n};\n\nconst postsResponse: ApiResponse<Post[]> = {\n  data: [{ id: 1, title: \'Hello\' }],\n  status: 200,\n  message: \'Success\'\n};\n```\n\n**Generic Classes:**\n```typescript\nclass DataStore<T> {\n  private items: T[] = [];\n  \n  add(item: T): void {\n    this.items.push(item);\n  }\n  \n  get(index: number): T {\n    return this.items[index];\n  }\n  \n  getAll(): T[] {\n    return this.items;\n  }\n}\n\n// Usage\nconst stringStore = new DataStore<string>();\nstringStore.add(\'hello\');\nconst str = stringStore.get(0); // Type: string\n\nconst numberStore = new DataStore<number>();\nnumberStore.add(42);\nconst num = numberStore.get(0); // Type: number\n```\n\n**Generic Constraints:**\n```typescript\n// Constrain T to have an \'id\' property\ninterface HasId {\n  id: number;\n}\n\nfunction updateItem<T extends HasId>(item: T, updates: Partial<T>): T {\n  return { ...item, ...updates };\n}\n\n// This works\nconst user = { id: 1, name: \'John\', email: \'john@example.com\' };\nconst updatedUser = updateItem(user, { name: \'Jane\' });\n\n// This would cause an error - no \'id\' property\n// const invalid = updateItem({ name: \'John\' }, { name: \'Jane\' });\n```\n\n**Real-world Example - API Hook:**\n```typescript\nfunction useApi<T>(url: string): {\n  data: T | null;\n  loading: boolean;\n  error: string | null;\n} {\n  const [data, setData] = useState<T | null>(null);\n  const [loading, setLoading] = useState(true);\n  const [error, setError] = useState<string | null>(null);\n  \n  useEffect(() => {\n    fetch(url)\n      .then(res => res.json())\n      .then((data: T) => setData(data))\n      .catch(err => setError(err.message))\n      .finally(() => setLoading(false));\n  }, [url]);\n  \n  return { data, loading, error };\n}\n\n// Usage with different types\nconst { data: user } = useApi<User>(\'/api/user/1\');\nconst { data: posts } = useApi<Post[]>(\'/api/posts\');\n```\n\n**Key Benefits:**\n1. **Type Safety**: Catch errors at compile time\n2. **Code Reuse**: One implementation works for multiple types\n3. **IntelliSense**: Better autocomplete and documentation\n4. **Maintainability**: Less duplicate code',
          sender: 'assistant',
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2 + 1000 * 60 * 3)
        }
      ]
    }
  ]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim()) {
      console.log('Sending message:', message);
      setMessage('');
    }
  };

  const formatTime = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / (1000 * 60));
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    return `${days}d ago`;
  };

  const activeConversationData = conversations.find(conv => conv.id === activeConversation);
  const messages = activeConversationData?.messages || [];

  return (
    <div className="min-h-screen bg-gray-950 text-white flex">
      {/* Sidebar */}
      <div className={`${sidebarOpen ? 'w-80' : 'w-16'} transition-all duration-300 bg-gray-900 border-r border-gray-800 flex flex-col`}>
        <div className="p-4">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-3 hover:bg-gray-800 rounded-xl transition-all duration-200 hover:scale-105"
          >
            <Menu size={20} />
          </button>
        </div>
        
        {sidebarOpen && (
          <div className="flex-1 px-4 pb-4">
            <button className="w-full flex items-center space-x-3 p-4 hover:bg-gray-800 rounded-xl transition-all duration-200 mb-6 border border-gray-800 hover:border-gray-700">
              <Plus size={18} />
              <span className="font-medium">New chat</span>
            </button>
            
            <div className="space-y-3">
              <div className="text-xs text-gray-500 uppercase tracking-wider px-3 py-2 font-semibold">
                Recent Conversations
              </div>
              {conversations.map((conv) => (
                <button
                  key={conv.id}
                  onClick={() => setActiveConversation(conv.id)}
                  className={`w-full flex items-start space-x-3 p-3 hover:bg-gray-800 rounded-xl transition-all duration-200 text-left group ${
                    activeConversation === conv.id ? 'bg-gray-800 border border-gray-700' : ''
                  }`}
                >
                  <MessageSquare size={16} className="mt-1 text-gray-400 group-hover:text-gray-300" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-200 truncate group-hover:text-white">
                      {conv.title}
                    </p>
                    <p className="text-xs text-gray-500 truncate mt-1">
                      {conv.lastMessage}
                    </p>
                    <p className="text-xs text-gray-600 mt-1">
                      {formatTime(conv.timestamp)}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}
        
        <div className="p-4 border-t border-gray-800">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-3 hover:bg-gray-800 rounded-xl transition-all duration-200 hover:scale-105"
          >
            <Settings size={20} />
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <header className="flex items-center justify-between p-6 border-b border-gray-800 bg-gray-950/80 backdrop-blur-sm">
          <div className="flex items-center space-x-4">
            <h1 className="text-2xl font-light">Gemini</h1>
            <div className="flex items-center space-x-2 bg-gray-800 px-4 py-2 rounded-full border border-gray-700">
              <span className="text-sm text-gray-300 font-medium">2.5 Flash</span>
              <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </div>
          </div>
          
          <div className="relative">
            <button
              onClick={() => setShowProfileMenu(!showProfileMenu)}
              className="w-10 h-10 rounded-full overflow-hidden hover:ring-2 hover:ring-blue-500 transition-all duration-200 hover:scale-105"
            >
              <img
                src={user?.avatar}
                alt={user?.name}
                className="w-full h-full object-cover"
              />
            </button>
            
            {showProfileMenu && (
              <div className="absolute right-0 mt-2 w-56 bg-gray-900 rounded-xl shadow-2xl border border-gray-800 py-2 z-50">
                <div className="px-4 py-3 border-b border-gray-800">
                  <p className="text-sm font-medium text-white">{user?.name}</p>
                  <p className="text-xs text-gray-400">{user?.email}</p>
                </div>
                <button
                  onClick={logout}
                  className="w-full text-left px-4 py-3 text-sm hover:bg-gray-800 transition-colors duration-200 text-gray-300 hover:text-white"
                >
                  Sign out
                </button>
              </div>
            )}
          </div>
        </header>

        {/* Chat Area */}
        <div className="flex-1 flex flex-col">
          {activeConversation && messages.length > 0 ? (
            // Chat Messages
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {messages.map((msg) => (
                <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`flex space-x-3 max-w-4xl ${msg.sender === 'user' ? 'flex-row-reverse space-x-reverse' : ''}`}>
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                      msg.sender === 'user' ? 'bg-blue-600' : 'bg-gray-800'
                    }`}>
                      {msg.sender === 'user' ? <User size={16} /> : <Bot size={16} />}
                    </div>
                    <div className={`rounded-2xl px-4 py-3 ${
                      msg.sender === 'user' 
                        ? 'bg-blue-600 text-white' 
                        : 'bg-gray-800 text-gray-100 border border-gray-700'
                    }`}>
                      <div className="whitespace-pre-wrap text-sm leading-relaxed">
                        {msg.content}
                      </div>
                      <div className={`text-xs mt-2 ${
                        msg.sender === 'user' ? 'text-blue-100' : 'text-gray-500'
                      }`}>
                        {formatTime(msg.timestamp)}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            // Welcome Screen
            <div className="flex-1 flex flex-col items-center justify-center p-8">
              <h2 className="text-5xl font-light mb-12 text-center">
                Hello, <span className="bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 bg-clip-text text-transparent animate-pulse bg-[length:200%_200%] animate-[gradient_3s_ease-in-out_infinite]">{user?.name}</span>
              </h2>
            </div>
          )}

          {/* Chat Input */}
          <div className="p-6 border-t border-gray-800 bg-gray-950/80 backdrop-blur-sm">
            <div className="max-w-4xl mx-auto">
              <form onSubmit={handleSendMessage} className="relative">
                <div className="bg-gray-900 rounded-3xl border border-gray-800 p-4 focus-within:border-gray-700 transition-all duration-200 hover:border-gray-700">
                  <div className="flex items-center space-x-4">
                    <button
                      type="button"
                      className="p-2 hover:bg-gray-800 rounded-full transition-all duration-200 hover:scale-105"
                    >
                      <Plus size={20} className="text-gray-400" />
                    </button>
                    
                    <input
                      type="text"
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="Ask Gemini"
                      className="flex-1 bg-transparent outline-none text-white placeholder-gray-500 text-lg"
                    />
                    
                    {message.trim() && (
                      <button
                        type="submit"
                        className="p-3 bg-blue-600 hover:bg-blue-700 rounded-full transition-all duration-200 hover:scale-105 shadow-lg"
                      >
                        <Send size={16} className="text-white" />
                      </button>
                    )}
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes gradient {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
      `}</style>
    </div>
  );
}