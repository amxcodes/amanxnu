import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Eye, EyeOff } from 'lucide-react';

export default function Login() {
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [step, setStep] = useState<'email' | 'password'>('email');

  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      setError('Please enter your email');
      return;
    }
    if (!email.includes('@')) {
      setError('Please enter a valid email address');
      return;
    }
    setError('');
    setStep('password');
  };

  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!password) {
      setError('Please enter your password');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      await login(email, password);
    } catch (err) {
      setError('Invalid email or password');
    } finally {
      setIsLoading(false);
    }
  };

  const handleBack = () => {
    setStep('email');
    setError('');
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-6">
            <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center mr-3 shadow-lg">
              <span className="text-white font-bold text-lg">G</span>
            </div>
            <h1 className="text-3xl font-light text-gray-800">Google</h1>
          </div>
          <h2 className="text-3xl font-normal text-gray-900 mb-2">
            {step === 'email' ? 'Sign in' : 'Welcome'}
          </h2>
          <p className="text-base text-gray-600">
            {step === 'email' ? 'Use your Google Account' : email}
          </p>
        </div>

        <div className="bg-white border border-gray-200 rounded-xl p-10 shadow-xl">
          {step === 'email' ? (
            <form onSubmit={handleEmailSubmit} className="space-y-6">
              <div>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Email or phone"
                  className="w-full px-4 py-4 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent transition-all duration-200 text-lg"
                  autoFocus
                />
              </div>
              {error && (
                <p className="text-red-600 text-sm font-medium">{error}</p>
              )}
              <div className="flex items-center justify-between">
                <button
                  type="button"
                  className="text-blue-600 hover:text-blue-700 text-sm font-semibold transition-colors duration-200"
                >
                  Forgot email?
                </button>
                <button
                  type="submit"
                  className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-semibold transition-all duration-200 hover:shadow-lg"
                >
                  Next
                </button>
              </div>
            </form>
          ) : (
            <form onSubmit={handlePasswordSubmit} className="space-y-6">
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  className="w-full px-4 py-4 pr-12 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent transition-all duration-200 text-lg"
                  autoFocus
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700 transition-colors duration-200"
                >
                  {showPassword ? <EyeOff size={22} /> : <Eye size={22} />}
                </button>
              </div>
              {error && (
                <p className="text-red-600 text-sm font-medium">{error}</p>
              )}
              <div className="flex items-center justify-between">
                <button
                  type="button"
                  onClick={handleBack}
                  className="text-blue-600 hover:text-blue-700 text-sm font-semibold transition-colors duration-200"
                >
                  Back
                </button>
                <button
                  type="submit"
                  disabled={isLoading}
                  className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed text-white px-8 py-3 rounded-lg font-semibold transition-all duration-200 hover:shadow-lg"
                >
                  {isLoading ? 'Signing in...' : 'Next'}
                </button>
              </div>
            </form>
          )}
        </div>

        <div className="text-center mt-8">
          <p className="text-sm text-gray-600">
            Not your computer? Use Guest mode to sign in privately.{' '}
            <a href="#" className="text-blue-600 hover:text-blue-700 transition-colors duration-200 font-medium">
              Learn more
            </a>
          </p>
        </div>

        <div className="flex justify-between items-center mt-8 text-sm">
          <div className="flex space-x-6">
            <a href="#" className="text-gray-600 hover:text-gray-800 transition-colors duration-200">
              Privacy
            </a>
            <a href="#" className="text-gray-600 hover:text-gray-800 transition-colors duration-200">
              Terms
            </a>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-gray-600">English (United States)</span>
          </div>
        </div>
      </div>
    </div>
  );
}